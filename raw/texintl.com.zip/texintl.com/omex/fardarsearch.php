<p align="center"><font face="Arial, Helvetica, sans-serif">Please wait loading...</font></p>
<div style="display:none">
		

     <form name="form1" method="post" action="http://www.fardar.com/websearch/podsearch.asp">
		  <table border="0" cellpadding="0" cellspacing="0" width="90%">
              <tbody><tr>
                <td height="20">&nbsp;</td>
              </tr>
              <tr> 
                <td height="50"> <div class="style1" align="center"> FDE Online Tracking

 </div></td>
              </tr>
              <tr> 
                <td>
                    <div align="center"> 
                      <textarea name="AWBNo" cols="30" rows="6" id="AWBNo" onBlur="value=value.replace(/(^\s+[\n|\r\n]|\s+[\n|\r\n]$)/g,'')"><?php echo $_REQUEST['AWBNo'];?></textarea>
                    </div>
                  </td>
              </tr>
              <tr> 
                <td><table align="center" border="0" cellpadding="0" cellspacing="0" height="24" width="40%">
                    <tbody><tr> 
                      <td>
                          <input name="Submit" value="confirm" type="submit">
                        </td>
                      <td>&nbsp;</td>
                      <td>
                        <input name="Submit2" value="cancel" type="reset">
                        </td>
                    </tr>
                  </tbody></table></td>
              </tr>
              <tr> 
                <td class="td1" height="40" valign="middle">            
    1. You can track your shipments online now by entering the shipment 
airwaybill numbers in the box provided here . <br>
                2. You may enter up to 10 airwaybill numbers, but please
 use a space or press 'Enter' on your keyboard to separate them . <br>                </td>
              </tr>
            </tbody></table>
	</form>
</div>

<script language="javascript">
document.form1.Submit.click();
</script>