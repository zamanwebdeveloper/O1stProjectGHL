<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<link rel="stylesheet" href="indexm_files/css3menu1/style.css" type="text/css" />



<!-- Start css3menu.com HEAD section -->
<link rel="stylesheet" href="indexm_files/css3menu1/style.css" type="text/css" />
<link rel="stylesheet" href="indexm_files/css3menu2/style.css" type="text/css" />
<!-- End css3menu.com HEAD section -->
<style type="text/css">
<!--
.style1 {
	color: #006600;
	font-weight: bold;
}
.style3 {
	color: #FF6600;
	font-weight: bold;
}
.style4 {color: #FFFFFF}
.style6 {
	color: #FF9900;
	font-weight: bold;
}
.style9 {color: #FFCC00}
.style10 {font-family: Arial, Helvetica, sans-serif}
.style11 {font-family: Arial, Helvetica, sans-serif; font-size: 13px; }
.style12 {font-size: 13px}
.style13 {font-family: Arial, Helvetica, sans-serif; font-size: 12px; }
.style14 {font-size: 12px}
.style15 {color: #FF9900}
-->
</style>
</head>
<body style="background-color:#EBEBEB" alink="#0099FF" vlink="#0099FF" link="#000000">
<table width="1299">
 <tr valign="middle" align="center"><td valign="middle" align="center">
<table border="0" cellpadding="0" cellspacing="0" style="BORDER-TOP-WIDTH: 0px; BORDER-LEFT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-COLLAPSE: collapse; BORDER-RIGHT-WIDTH: 0px" bordercolor="#ffffff" width="800" id="AutoNumber1" height="459" bgcolor="#ffffff">
  <tr height="5" bgcolor="#6A87EA" valign="middle">
    <td width="100%" height="103" bordercolor="#FFFFFF" bgcolor="#FFFFFF" style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none">
      <table height="110">
        <tr><td width="382" height="104"><img src="img/banner-top.gif"></td>
        <td width="406" height="104"><p>
          <object classid="clsid:D27CDB6E-AE6D-11cf-96B8-444553540000" codebase="http://download.macromedia.com/pub/shockwave/cabs/flash/swflash.cab#version=7,0,19,0" width="406" height="102">
            <param name="movie" value="img/movie1.swf">
            <param name="quality" value="high">
            <embed src="img/movie1.swf" quality="high" pluginspage="http://www.macromedia.com/go/getflashplayer" type="application/x-shockwave-flash" width="406" height="102"></embed>
          </object>
        </p>          </td>
  </tr></table
      ></td>
  </tr>
  <tr valign="top"><td height="27"><table height="27" bgcolor="#006666">
    <tr bgcolor="#358EBD">
    <td width="800" height="21"><div align="right">
      <table align="right">
        <tr>
          <td><div align="right"><span class="style16"><span class="style19"> <span class="style33 style6 style9 style10"><span class="style33 style15 style12"><a href="Log-in.html">Login</a> </span></span></span><span class="style18 style6 style9 style10 style12"><span class="style18 style15"><a href="News.html"></a></span></span></span></div></td>
          <td><div align="right"><span class="style16"><span class="style19"> <span class="style33 style6 style9 style10"><span class="style33 style15 style12"><a href="Log-in.html"></a> </span></span></span><span class="style18 style6 style9 style10 style12"><span class="style18 style15"><a href="News.html">News </a></span></span></span></div>
          </tr>
      </table>
    </div></td>
  </tr></table></td>
  </tr>
     <tr>
    <td width="100%" style="BORDER-RIGHT: #111111; BORDER-TOP: medium none; BORDER-LEFT: #111111; BORDER-BOTTOM: medium none" height="3">
	
	</td>
  </tr>
    <tr valign="top"><td height="171" valign="top"><table  vspace="10" hspace="10" bgcolor="#358EBD" background="img/middle-banner.gif"><tr bgcolor="" valign="top"><td width="800" height="165" valign="top">
   <table vspace="20" hspace="20"><tr valign="top"><td width="149" height="157" valign="top"><TABLE height="93">
     <TR><TD width="149"></TD>
   </TR>
   <TR><TD>&nbsp;</TD>
   </TR>
   <TR>
     <TD><span class="style24">HOME</span></TD>
   </TR>
   <TR>
     <TD><span class="style24">NEWS</span></TD>
   </TR>
   <TR>
     <TD><span class="style24">HOLIDAYS</span></TD>
   </TR>
   
   </TABLE>
     </td><td width="631">
	 <table width="635">
	   <tr><td width="377" height="149"></td>
	 <td width="246" valign="bottom"><table width="215" height="82" align="right">
	   <tr bgcolor="#FFFFFF" valign="bottom">
	     <td width="207" valign="bottom"><p align="center" class="style36"><span class="style1">Track Shipment</span><br>
		     <span class="style39">Enter your tracking number</span><br>
		     <input type="text" name="textfield">
		     <span class="style3">GO</span><br>
		     <em>Track Several Shipmen</em>t  &gt;&gt;		 
	       </td>
	 </tr></table></td>
	   </tr></table>
	 </td>
   </tr></table>
   
   </td>
  </tr></table></td>
  </tr>
     <tr>
    <td width="100%" style="BORDER-RIGHT: #111111; BORDER-TOP: medium none; BORDER-LEFT: #111111; BORDER-BOTTOM: medium none" height="2">	</td>
  </tr>
  <tr height="211">
    <td width="100%" style="BORDER-RIGHT: #111111; BORDER-TOP: medium none; BORDER-LEFT: #111111; BORDER-BOTTOM: medium none" height="27" bgcolor="#ffffff">
   <table width="800" background="img/banner-middle.gif">
   <tr>
     <td width="792"></td>
   </tr>
   <tr align="center" valign="top">


<td align="center" valign="middle">

<!-- Start css3menu.com BODY section id=2 -->
<p style="display:none"><a href="http://css3menu.com/">CSS3 Fixed Menu Css3Menu.com</a></p>
<!-- End css3menu.com BODY section --></td>
   </tr>
   <tr valign="top"><td valign="top" align="center"><table width="783" border="1">
     <tr>
       <td width="773"><table>
         <tr>
           <td></td>
         </tr>
         <tr>
           <td width="55"></td>
         </tr>
         <tr valign="top">
     <td ><link rel="stylesheet" href="styles.css" type="text/css" />
        <div id="tabs">
         <ul>
            <li><a href="index.php" class="anchor"><span><strong>Home</strong></span></a></li>
            <li><a href="about_us.php" class="anchor"><span><strong>About Us</strong></span></a></li>
            <li><a href="services.php" class="anchor"><span><strong>Support Services</strong></span></a></li>
			<li><a href="country.php" class="anchor"><span><strong>Network</strong></span></a></li>
            <li><a href="terms_condition.php" class="anchor"><span><strong>Terms Condition</strong></span></a></li>
			<li><a href=".php" class="anchor"><span><strong>Tracking</strong></span></a></li>
			<li><a href="contact_us.php" class="anchor"><span><strong>Contact Us</strong></span></a></li>
			<li><a href="feedback.php" class="anchor"><span><strong>Feedback</strong></span></a></li>
			<li><a href="" class="anchor"><span><strong>Webmail</strong></span></a></li>
			<li><a href="" class="anchor"><span><strong>Log-In</strong></span></a></li>
          </ul>
        </div></td>
   </tr>
       </table></td>
     </tr>
   </table>
    </td>
      </tr>
	  <tr>
	    <td align="center">
		<table width="782" hspace="10" vspace="10">
		  <tr><td width="774"><div align="justify">
		    <TABLE border="0" cellSpacing="0" cellPadding="0" width="100%" height="50">
              <TBODY>
                <TR>
                  <TD>NEWS &amp; CAREERS<BR></TD>
                </TR>
              </TBODY>
		      </TABLE>
		    <TABLE border="0" cellSpacing="0" cellPadding="0" width="100%">
              <TBODY>
                <TR>
                  <TD vAlign="top" width="10"> </TD>
                  <TD vAlign="top"><DIV id="container">
                        <DIV id="content">
                          <!--INSERT CONTENT HERE-->
                          <BR>
                          <DIV align="left">Sorry, there is no news posted at present</DIV>
                        </DIV>
                    </DIV></TD>
                </TR>
              </TBODY>
		      </TABLE>
		    <p class="style11">&nbsp;</p>
		    </div></td></tr></table>
		</td>
	  </tr>
   </table>
   </td>
  </tr>
  <tr>
    <td width="100%" style="BORDER-RIGHT: #111111; BORDER-TOP: medium none; BORDER-LEFT: #111111; BORDER-BOTTOM: medium none" height="16">
	<table bgcolor="#006666"><tr bgcolor="" align="center">
	  <td width="800" height="21"><div align="right"><span class="style28 style6 style9 style10"><span class="style28 style15 style12">Privacy Statement l Legal Notice </span></span></div></td>
	</tr></table>
	</td>
  </tr>
   <tr>
    <td width="100%" style="BORDER-RIGHT: #111111; BORDER-TOP: medium none; BORDER-LEFT: #111111; BORDER-BOTTOM: medium none" height="3">
	
	</td>
  </tr>
   <tr>
    <td width="100%" style="BORDER-RIGHT: #111111; BORDER-TOP: medium none; BORDER-LEFT: #111111; BORDER-BOTTOM: medium none" height="16">
	<table bgcolor="#006633"><tr bgcolor="#006666"><td width="800" height="34"><div align="center" class="style29 style12"><span class="style26 style4">Copyright &copy; 20012 - 201 GLOBAL Post.              All rights reserved.  Powered by </span><span class="style30 style4"><a href="http://www.ssmtech.net" target="_blank">SSM Technology</a></span></div></td>
	</tr></table>
	</td>
  </tr>
</table>
</td></tr>
</table>
</body>
</html>
