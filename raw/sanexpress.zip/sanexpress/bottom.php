<table width="900" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td height="49" background="item/bg.jpg"><div align="center"> 
        <table width="900" border="0">
          <tr> 
            <td width="658"><div align="center">Copyright &copy; 2009 All rights 
                reserved Bengal Super Post</div></td>
            <td width="226"><div align="center">design &amp; hosting by : cyberhosting.us</div></td>
          </tr>
        </table>
      </div></td>
  </tr>
</table>
