<?php 
include('db_conn.php');


$hawb_no=$_REQUEST['hawb_num'];
$origin=$_REQUEST['origin'];
$destination=$_REQUEST['destination'];
$through=$_REQUEST['through'];
$awb_no=$_REQUEST['awb_num'];
$date=$_REQUEST['pdate'];
$edate=$_REQUEST['edate'];
$shipper=$_REQUEST['shipper'];
$receiver=$_REQUEST['receiver'];
$prduct=$_REQUEST['product'];
$stutus=$_REQUEST['status'];

$smobile=$_REQUEST['smobile'];
$semail=$_REQUEST['semail'];
$saddress=$_REQUEST['saddress'];
$rmobile=$_REQUEST['rmobile'];
$remail=$_REQUEST['remail'];
$raddress=$_REQUEST['raddress'];

$agentname=$_REQUEST['agentname'];
$refname=$_REQUEST['refname'];

$cLocation=$_REQUEST['cLocation'];

$pcs=$_REQUEST['pcs'];
$weight=$_REQUEST['weight'];

$res=add_shipment($hawb_no, $origin, $destination, $through, $awb_no, $date, $shipper, $receiver, $prduct, $stutus,$smobile,$semail,$saddress,$rmobile,$remail,$raddress,$edate,$agentname,$refname,$cLocation,$pcs,$weight);

if($res)
{
	echo "<script> alert('information successfully added'); </script>";
	echo "<script> window.location='login_view.php?page=addtract.php'; </script>";
	
}
else
{
	echo "<script> alert('information is wrong'); </script>";
	echo "<script> window.location='login_view.php?page=addtract.php'; </script>";
}


?>