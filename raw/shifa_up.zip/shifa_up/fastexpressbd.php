<html> 
<meta http-equiv="Content-Type" content="text/html; charset=big5">
<body>
<p align="center">Please wait loading...</p>
<div style="display:none">
		

<form action="http://fastPostbd.com/shipment.php" method="post" name="form1" id="form1"> 
					<input type="text" name="hawbno2" value="<?php echo $_REQUEST['AWBNo']; ?>"> <input name='submit' type='submit' value=' GO '> 
<script>
document.form1.submit.click();
</script>
</body>
</html>