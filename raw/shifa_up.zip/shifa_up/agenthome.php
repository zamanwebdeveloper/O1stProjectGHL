<?php 
$user=$_SESSION['member_ID'];
//echo $user;
?>
<html>
<title>Welcome To BengalPost</title>
<head>

<script type="text/javascript" language="JavaScript1.2" src="stm31.js"></script>
</head>
<body>
<?php include('head.php');?>
<br>

<table width="80%" border="0" align="center" background="item/List.gif">
  <tr>
    <td height="26"><div align="right"><img src="item/logout.gif" width="16" height="14"><a href="logout.php">Log Out</a></div></td>
  </tr>
</table>

<table width="80%" height="256" border="0" align="center" background="item/he2.jpg">
  <tr> 
    <td width="18%" valign="top"> 

<script type="text/javascript" language="JavaScript1.2">
<!--
beginSTM("lljuchr","static","0","0","left","false","false","310","0","0","250","","blank.gif");
beginSTMB("auto","0","0","vertically","blank.gif","0","0","0","3","#996600","","tiled","#cccccc","0","none","0","Normal","10","4","4","0","0","0","0","0","#000000","false","#cccccc","#cccccc","#cccccc","none");
appendSTMI("false","Agent&nbsp;fillup&nbsp;form","left","middle","","","-1","-1","0","normal","#990000","#990000","","0","-1","-1","blank.gif","blank.gif","4","4","1","","","_self","Arial","9pt","#cccccc","bold","normal","none","Arial","9pt","#ffffff","bold","normal","none","3","solid","#cc0000","#822000","#610000","#bf0000","#822000","#cc0000","#bf0000","#610000","","","","tiled","tiled");
beginSTMB("auto","-10","0","vertically","","0","0","0","3","#ffffff","","tiled","#000000","0","none","20","Normal","10","4","4","0","0","0","0","0","#7f7f7f","false","#000000","#000000","#000000","none");
appendSTMI("false","Documents&nbsp;only","left","middle","","","-1","-1","0","normal","#990000","#990000","","0","-1","-1","blank.gif","blank.gif","4","4","1","","destination.php","_self","Arial","9pt","#cccccc","bold","normal","none","Arial","9pt","#ffffff","bold","normal","none","3","solid","#cc0000","#822000","#610000","#bf0000","#822000","#cc0000","#bf0000","#610000","destination.php","","","tiled","tiled");
endSTMB();
appendSTMI("false","Report","left","middle","","","-1","-1","0","normal","#990000","#990000","","0","-1","-1","blank.gif","blank.gif","4","4","1","","","_self","Arial","9pt","#cccccc","bold","normal","none","Arial","9pt","#ffffff","bold","normal","none","3","solid","#cc0000","#822000","#610000","#bf0000","#822000","#cc0000","#bf0000","#610000","","","","tiled","tiled");
beginSTMB("auto","-10","0","vertically","","0","0","0","3","#ffffff","","tiled","#000000","0","none","20","Normal","10","4","4","0","0","0","0","0","#7f7f7f","false","#000000","#000000","#000000","none");
appendSTMI("false","Date&nbsp;Wise&nbsp;Report","left","middle","","","-1","-1","0","normal","#990000","#990000","","0","-1","-1","blank.gif","blank.gif","4","4","1","","report_date_agent.php","_self","Arial","9pt","#cccccc","bold","normal","none","Arial","9pt","#ffffff","bold","normal","none","3","solid","#cc0000","#822000","#610000","#bf0000","#822000","#cc0000","#bf0000","#610000","report_date_agent.php","","","tiled","tiled");
appendSTMI("false","Destination&nbsp;Report","left","middle","","","-1","-1","0","normal","#990000","#990033","","1","-1","-1","blank.gif","blank.gif","4","4","1","","select_trac_info_agent.php","_self","Arial","9pt","#cccccc","bold","normal","none","Arial","9pt","#ffffff","bold","normal","none","3","solid","#cc0000","#990000","#610000","#bf0000","#990000","#cc0000","#bf0000","#610000","select_trac_info_agent.php","","","tiled","tiled");
endSTMB();
endSTMB();
endSTM();
//-->
</script>

 </td>
    <td width="82%" valign="top"><div align="center"> 
        <h1 align="center">Welcome<br>
          To <br>
          Agent</h1>
      </div></td>
  </tr>
</table>
<p>&nbsp; </p>
</body>
</html>