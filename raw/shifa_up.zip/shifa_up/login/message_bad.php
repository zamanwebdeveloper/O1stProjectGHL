<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8" />
    <meta http-equiv="X-UA-Compatible" content="IE=EmulateIE7" />
<title>Dr. Rumi's Dental &amp; Orthodontic Clinic</title>
<script type="text/javascript" src="scripts/script.js"></script>
<link rel="stylesheet" href="css/style_screen.css" type="text/css" media="screen" />
<!--[if IE 6]><link rel="stylesheet" href="style.ie6.css" type="text/css" media="screen" /><![endif]-->
<!--[if IE 7]><link rel="stylesheet" href="style.ie7.css" type="text/css" media="screen" /><![endif]-->
<script type="text/javascript" src="scripts/ibox.js"></script>
<script type="text/javascript">iBox.setPath('scripts/');</script>	
<style type="text/css">
body {
	margin-top:0;
	margin-bottom:0;
	margin-left:0;
	margin-right:0;
	background-color:#FFFFFF;
	overflow:hidden;
}
</style>
</head>
<body>
<table width="100%" cellpadding="0" cellspacing="0" align="center" border="0">
	<tr height="<?php echo ($_GET['h']-200);?>">
		<td align="center" valign="middle">
<table width="450" border="0" cellpadding="0" cellspacing="0"><tr><td>
<div class="Block">
     <div class="Block-tl"></div>
     <div class="Block-tr"></div>
     <div class="Block-bl"></div>
     <div class="Block-br"></div>
     <div class="Block-tc"></div>
     <div class="Block-bc"></div>
     <div class="Block-cl"></div>
     <div class="Block-cr"></div>
     <div class="Block-cc"></div>
     <div class="Block-body">
     <div class="BlockHeader">
          <div class="l"></div>
          <div class="r"></div>
               <div class="t"><font color="#CC0000">Error</font></div>
		  </div>
			   <?php echo $_GET['m'];?>
	</div>
</div>
</td></tr></table>
</td></tr></table>
</body>
</html>