<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
<head>
<title>Welcome to Visit Bengal Post</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">

<script language="JavaScript">
<!--
function mmLoadMenus() {
  if (window.mm_menu_0913115257_0) return;
  window.mm_menu_0913115257_0 = new Menu("root",98,18,"",12,"#000000","#FFFFFF","#CCCCCC","#000084","left","middle",3,0,1000,-5,7,true,true,true,0,true,true);
  mm_menu_0913115257_0.addMenuItem("International","location='inter_tracking.php'");
  mm_menu_0913115257_0.addMenuItem("Domestic","location='domestic_tracking.php'");
   mm_menu_0913115257_0.hideOnMouseOut=true;
   mm_menu_0913115257_0.bgColor='#555555';
   mm_menu_0913115257_0.menuBorder=1;
   mm_menu_0913115257_0.menuLiteBgColor='#FFFFFF';
   mm_menu_0913115257_0.menuBorderBgColor='#008000';

mm_menu_0913115257_0.writeMenus();
} // mmLoadMenus()
//-->
</script>
<script language="JavaScript" src="mm_menu.js"></script>


<link href="css/generalrules.css" rel="stylesheet" type="text/css">
</head>

<body leftmargin="0" topmargin="0" marginheight="0">
<script language="JavaScript1.2">mmLoadMenus();</script>
<table width="99%" border="0" align="center" cellpadding="0" cellspacing="0">
  <tr> 
    <td width="922" height="21" bgcolor="#FFFFFF"><div align="right"><a href="home.php" class="Abrand">HOME</a> 
        | <a href="about.php" class="Abrand">ABOUT US</a> | <a href="service.php" class="Abrand">SERVICE</a> 
        | <a href="network.php" class="Abrand">NETWORK</a> |<a href="support.php" class="Abrand"> 
        LOGISTIC SUPPORT </a>|<a href="#" name="link1" class="Abrand" id="link1" onMouseOver="MM_showMenu(window.mm_menu_0913115257_0,0,14,null,'link1')" onMouseOut="MM_startTimeout();">TRACKING</a> 
        | <a href="contact.php" class="Abrand">CONTACT US</a> | <a href="form.php" class="Abrand">ONLINE 
        FORM </a> | <a href="webmail" class="Abrand">WEBMAIL</a></div></td>
    <td width="77" bgcolor="#FFFFFF">&nbsp;</td>
  </tr>
</table>
</body>
</html>
