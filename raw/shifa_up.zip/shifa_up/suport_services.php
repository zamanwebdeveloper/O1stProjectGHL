
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN" "http://www.w3.org/TR/html4/loose.dtd">
<html>
<head>
<link href="css/generalrules.css" rel="stylesheet" type="text/css">
<style type="text/css">
<!--
.style2 {font-size: 11px}
.style4 {font-size: 12px}
.style6 {font-size: 12px; color: #000000; }
-->
</style>

<script language="JavaScript" src="mm_menu.js"></script>
	<meta http-equiv="content-type" content="text/html; charset=utf-8" />
	<link rel="stylesheet" href="indexm_files/css3menu1/style.css" type="text/css" />



<!-- Start css3menu.com HEAD section -->
<link rel="stylesheet" href="indexm_files/css3menu1/styles3.css" type="text/css" />
<link rel="stylesheet" href="indexm_files/css3menu2/styles3.css" type="text/css" />
<link rel="stylesheet" href="styles3.css" type="text/css" />
<!-- End css3menu.com HEAD section -->
<style type="text/css">
<!--
.style3 {
	color: #FFCC01;
	font-weight: bold;
}
.style4 {color: #FFFFFF}
.style6 {
	color: #FF9900;
	font-weight: bold;
}
.style9 {color: #FFCC00}
.style10 {font-family: Arial, Helvetica, sans-serif}
.style12 {font-size: 13px}
.style15 {color: #FF9900}
.style16 {color: #FF0000}
-->
</style>
</head>
<body style alink="" vlink="#0099FF" link="#07568F">
<table width="1299">
 <tr valign="middle" align="center"><td valign="middle" align="center">
<table border="0" cellpadding="0" cellspacing="0" style="BORDER-TOP-WIDTH: 0px; BORDER-LEFT-WIDTH: 0px; BORDER-BOTTOM-WIDTH: 0px; BORDER-COLLAPSE: collapse; BORDER-RIGHT-WIDTH: 0px" bordercolor="#ffffff" width="800" id="AutoNumber1" height="494" bgcolor="#ffffff">
  <tr height="5" bgcolor="#6A87EA" valign="middle">
    <td width="100%" height="19" valign="top" bordercolor="#FFFFFF" bgcolor="#FFFFFF" style="BORDER-RIGHT: medium none; BORDER-TOP: medium none; BORDER-LEFT: medium none; BORDER-BOTTOM: medium none" align="right"><a href="bengal/home.php" class="anchor"><span><strong>User Log-In</strong></span></a></td>
  </tr>
     <tr>
    <td width="100%" style="BORDER-RIGHT: #111111; BORDER-TOP: medium none; BORDER-LEFT: #111111; BORDER-BOTTOM: medium none" height="2">	</td>
  </tr>
    <tr valign="top"><td height="171" valign="top" ><table  vspace="10" hspace="10" bgcolor="#358EBD" background="img/44.jpg"><tr bgcolor="" valign="top"><td width="800" height="165" valign="top">
   <table vspace="20" hspace="20"><tr valign="top" ><td width="149" height="157" valign="top"><TABLE height="90"  align="right">
     <TR><TD width="149"></TD>
   </TR>
   <TR><TD>&nbsp;</TD>
   </TR>
   <TR>
     <TD>&nbsp;</TD>
   </TR>
   <TR>
     <TD height="16">&nbsp;</TD>
   </TR>
   <TR>
     <TD>&nbsp;</TD>
   </TR>
   
   </TABLE>
     </td><td width="631">
	 <table width="635">
	   <tr><td width="408" height="149"><div align="right" ><br>
	     <span class=""><br>
	     <br>
	     <br>
	     <br>
		 <br>
		 <br>
		 <br>
	     <em><strong><b>Check your tracking number</b></strong></em></span></div>
	       <div align="right"><span class="style36 style16"><em>Track Several Shipment </em> &gt;&gt; </span></div></td>
	 <td width="215" valign="bottom"><table width="215" height="42" align="right">
	   <tr bgcolor="" valign="bottom">
	     <td width="250" valign="bottom"><p align="center" class="style36">
	       
		     <span class="style3"><a href="inter_tracking.php" class="anchor"><input type="button"name="textfield" value="Please Click GO"></a></span><br>
	     </td>
	 </tr></table></td>
	   </tr></table>
	 </td>
   </tr></table>
   
   </td>
  </tr></table></td>
  </tr>
     <tr>
    <td width="100%" style="BORDER-RIGHT: #111111; BORDER-TOP: medium none; BORDER-LEFT: #111111; BORDER-BOTTOM: medium none" height="2">	</td>
  </tr>
  <tr height="211">
    <td width="100%" style="BORDER-RIGHT: #111111; BORDER-TOP: medium none; BORDER-LEFT: #111111; BORDER-BOTTOM: medium none" height="27" bgcolor="#ffffff">
   <table width="800" bgcolor="#FFFFFF">
   <tr>
     <td width="792"></td>
   </tr>
   <tr align="center" valign="top">


<td align="center" valign="middle">

<!-- Start css3menu.com BODY section id=2 -->
<p style="display:none"><a href="http://css3menu.com/">CSS3 Fixed Menu Css3Menu.com</a></p>
<!-- End css3menu.com BODY section --></td>
   </tr>
   <tr valign="top">
     <td ><link rel="stylesheet" href="styles3.css" type="text/css" />
        <div class="navigation">
          <ul>
            <li><a href="index.php" class="anchor"><span><strong>Home</strong></span></a></li>
            <li><a href="about_us.php" class="anchor"><span><strong>About Us</strong></span></a></li>
            <li><a href="suport_services.php" class="anchor"><span><strong>Support Services</strong></span></a></li>
			<li><a href="country.php" class="anchor"><span><strong>Network</strong></span></a></li>
            <li><a href="terms_condition.php" class="anchor"><span><strong>Terms Condition</strong></span></a></li>
			<li><a href="inter_tracking.php" class="anchor"><span><strong>Tracking</strong></span></a></li>
			<li><a href="contact_us.php" class="anchor"><span><strong>Contact Us</strong></span></a></li>
			<li><a href="feedback.php" class="anchor"><span><strong>Feedback</strong></span></a></li>
			<li><a href="" class="anchor"><span><strong>Webmail</strong></span></a></li>
			
          </ul>
        </div></td>
   </tr>
	  <tr>
	    <td height="234" align="center"><table width="804">
          <tr valign="top">
            <td height="153"><img src="img/banner.jpg" width="804" height="208"></td>
            </tr>
        </table>
	      <table width="100%" cellspacing="2" cellpadding="2">
            <tr>
              <td><table width="100%" cellspacing="2" cellpadding="2">
                <tr>
                  <TR>
                              <TD><strong>Our Mission</strong><br>
To meet the customer’s expectations by the highest standards of service quality  with strong professionalism and commitment. </TD>
                            </TR>
                          
                            <TR>
                              <TD><strong><br>
                                Our Vision</strong><br>
To work a team to become a world class service provider of total transportation  services in any corner of the nation and the world<BR>
<strong><br>
Our Team</strong><strong><br>
                                </strong>All local and Worldwide offices are staffed by  friendly, professional and highly trained personnel with utmost knowledge and  experience in every area of our business to ensure the best possible attention  for your documents and parcels. </TD>
                            </TR>
                            <TR>
                              <TD><strong><br>
                                Product Service </strong><br>
                                    <strong>Local</strong> - Security Items, cheque book, Credit Card, Debit Card, Tin, Pin, L/C  document ,Cell Phone Bill,  Statements, Share document.<br>
                                    <strong>Internationa</strong>l –  Any kind of  sensitive document, parcel inbound &amp; outbound service.</TD>
                            </TR>
                            <TR>
                              <TD valign="top"><p><strong>                                Our Services</strong>:<br>
                                *Premier  Service   * Special Service   *Secured Service * General Service</p>
                                <p><strong>Service definition</strong>:</p></TD>
                            </TR>
                            <TR>
                              <TD><p><strong>                                Premier Service </strong>-  Out sourcing  work, collection &amp; delivery any corner in  the country.</p></TD>
                            </TR>
                            <TR>
                              <TD><p><strong>Special Service</strong>  -  Same day delivery, branch  to   branch collection &amp; delivery.<IMG src="Images/spacer.gif" width="1" height="1"></p>                                </TD>
                            </TR>
                            <TR>
                              <TD><p><strong>Secured Service</strong> -  Valuable  parcel like – MICR chaque box, Tin box, Pin box, Card box,Cash equivalent any Items.</p></TD>
                            </TR>
                            <TR>
                              <TD><strong>General Service</strong> -  Next day delivery with strong  professionalism</TD>
                            </TR>
                            <TR>
                              <TD><strong><br>
                                Area Covered</strong> -  All over the country, Important place  &amp; business centre.</TD>
                            </TR>
                            <TR>
                              <TD>&nbsp;</TD>
                            </TR>
            </tr>
          </table></td>
	  </tr>
   </table>   </td>
  </tr>
   <tr>
    <td width="100%" style="BORDER-RIGHT: #111111; BORDER-TOP: medium none; BORDER-LEFT: #111111; BORDER-BOTTOM: medium none" height="16">
	<table align="center" bgcolor="#006666">
	  <tr bgcolor="" align="center">
	  <td width="800" height="21"><div ><span class="style28 style6 style9 style10"><span class="style28 style15 style12">Privacy Statement l Legal Notice </span></span></div>
	  </td>
	</tr></table>
	</td>
  </tr>
    <td width="100%" style="BORDER-RIGHT: #111111; BORDER-TOP: medium none; BORDER-LEFT: #111111; BORDER-BOTTOM: medium none" height="3">
	
	</td>
  </tr>
  <tr>
    <td width="100%" style="BORDER-RIGHT: #111111; BORDER-TOP: medium none; BORDER-LEFT: #111111; BORDER-BOTTOM: medium none" height="16">
	<table align="center" bgcolor="#006633">
	  <tr bgcolor="#006666"><td width="800" height="34"><div align="center" class="style29 style12">
	  <div align="center"><span class="style26 style4">Copyright &copy; 20012 - 201 GLOBAL Post.              All rights reserved.  Powered by </span><span class="style30 style4">SSM Technology</a></span></div>
	</div></td>
	</tr></table>
	</td>
  </tr>
</table>
</td></tr>
</table>
</body>
</html>
